// ─── 资质类型（四模块）──────────────────────────────────────────
export const QUAL_TYPES = [
  "high_tech",
  "innovative_sme",
  "specialized_sme",
  "little_giant",
] as const;

export type QualificationType = (typeof QUAL_TYPES)[number];

export const QUAL_TYPE_META: Record<
  QualificationType,
  { label: string; shortLabel: string; ministry: "MOST" | "MIIT"; color: string }
> = {
  high_tech:       { label: "高企认定",         shortLabel: "高企",   ministry: "MOST", color: "blue"   },
  innovative_sme:  { label: "创新型中小企业",   shortLabel: "创新",   ministry: "MIIT", color: "violet" },
  specialized_sme: { label: "专精特新中小企业", shortLabel: "专精",   ministry: "MIIT", color: "amber"  },
  little_giant:    { label: '专精特新"小巨人"', shortLabel: "小巨人", ministry: "MIIT", color: "rose"   },
};

// ─── 八大领域 ───────────────────────────────────────────────────
export const TECH_FIELDS = [
  "电子信息",
  "生物与新医药",
  "航空航天",
  "新材料",
  "高技术服务",
  "新能源与节能",
  "资源与环境",
  "先进制造与自动化",
] as const;

export type TechField = (typeof TECH_FIELDS)[number];

// ─── 街道/乡镇 ──────────────────────────────────────────────────
export type AdministrativeUnitType = "street" | "town";

export const ADMINISTRATIVE_UNITS = [
  { name: "柏泉街道", type: "street" },
  { name: "辛安渡街道", type: "street" },
  { name: "吴家山街道", type: "street" },
  { name: "将军路街道", type: "street" },
  { name: "径河街道", type: "street" },
  { name: "金银湖街道", type: "street" },
  { name: "慈惠街道", type: "street" },
  { name: "走马岭街道", type: "street" },
  { name: "新沟镇", type: "town" },
  { name: "东山街道", type: "street" },
] as const satisfies readonly { name: string; type: AdministrativeUnitType }[];

export const STREETS = ADMINISTRATIVE_UNITS.map((unit) => unit.name);

export type Street = (typeof STREETS)[number];

// ─── 湖北省城市→区县映射 ──────────────────────────────────────────
export const HUBEI_REGIONS: Record<string, string[]> = {
  "武汉市": [
    "东西湖区", "武汉经开区", "东湖高新区",
    "江岸区", "江汉区", "硚口区", "汉阳区", "武昌区", "青山区",
    "洪山区", "蔡甸区", "江夏区", "黄陂区", "新洲区",
  ],
  "宜昌市": [
    "西陵区", "伍家岗区", "点军区", "猇亭区", "夷陵区", "宜昌高新区",
    "宜都市", "当阳市", "枝江市",
    "远安县", "兴山县", "秭归县", "长阳土家族自治县", "五峰土家族自治县",
  ],
  "襄阳市": [
    "樊城区", "襄城区", "高新区", "东津新区",
    "老河口市", "枣阳市", "宜城市",
    "南漳县", "谷城县", "保康县",
  ],
  "荆州市": [
    "沙市区", "荆州区",
    "石首市", "洪湖市", "松滋市",
    "公安县", "监利市", "江陵县",
  ],
  "黄冈市": [
    "黄州区",
    "麻城市", "武穴市",
    "红安县", "罗田县", "英山县", "浠水县", "蕲春县", "黄梅县", "团风县",
  ],
  "孝感市": [
    "孝南区",
    "汉川市", "应城市", "安陆市",
    "孝昌县", "大悟县", "云梦县",
  ],
  "荆门市": [
    "东宝区", "掇刀区",
    "钟祥市", "京山市", "沙洋县",
  ],
  "黄石市": [
    "黄石港区", "西塞山区", "下陆区", "铁山区",
    "大冶市", "阳新县",
  ],
  "十堰市": [
    "茅箭区", "张湾区",
    "丹江口市",
    "郧阳区", "郧西县", "竹山县", "竹溪县", "房县",
  ],
  "咸宁市": [
    "咸安区", "赤壁市",
    "嘉鱼县", "通城县", "崇阳县", "通山县",
  ],
  "随州市": ["曾都区", "广水市", "随县"],
  "恩施土家族苗族自治州": [
    "恩施市", "利川市",
    "建始县", "巴东县", "宣恩县", "咸丰县", "来凤县", "鹤峰县",
  ],
  "鄂州市": ["鄂城区", "华容区", "梁子湖区"],
  "潜江市": ["潜江市"],
  "仙桃市": ["仙桃市"],
  "天门市": ["天门市"],
  "神农架林区": ["神农架林区"],
};

// ─── 申报类型 & 申报意愿 ─────────────────────────────────────────
export type DeclarationType = "新申报" | "复审";
export type DeclarationWillingness = "strong" | "moderate" | "hesitant" | "refused" | "unknown";

export const DECLARATION_WILLINGNESS_LABELS: Record<DeclarationWillingness, string> = {
  strong: "意愿强烈",
  moderate: "基本意愿",
  hesitant: "犹豫观望",
  refused: "明确拒绝",
  unknown: "未接触",
};

// ─── 企业原始数据 ───────────────────────────────────────────────
export interface Company {
  id: string;
  name: string;
  creditCode: string;
  city: string;
  district: string;
  street: string;
  industry: string;
  techField: TechField | null;
  establishedAt: string; // ISO date string
  registeredCapital: number; // 万元
  employees: number; // 参保人数
  rdEmployees: number; // 研发人员数（招聘推算）
  patents: {
    invention: number;
    utility: number;
    design: number;
  };
  software: number; // 软著数
  alreadyCertified: boolean; // 已是高企
  inSMEDatabase: boolean; // 科技型中小企业入库
  risk: {
    abnormal: boolean;
    penalty: boolean;
  };
  contact: {
    name: string;
    phone: string;
    email: string;
  };
  declarationWillingness: DeclarationWillingness;

  // ─── MIIT 三类资质扩展字段（可选，不破坏现有数据）──────────────
  annualRevenue?: number;       // 万元，年主营业务收入
  mainBizRevenueRatio?: number; // 主营收入占比 %
  rdExpenseRatio?: number;      // 研发费用占主营收入比 %
  marketRank?: number | null;   // 细分市场排名（null=未知）
}

// ─── 知识产权明细条目 ────────────────────────────────────────────
export type IPType = "invention" | "utility" | "design" | "software";

export interface IPItem {
  name: string;
  number: string;
  type: IPType;
  status: string;
  date: string; // YYYY-MM-DD
}

// ─── 任务 ───────────────────────────────────────────────────────
export type TaskStatus = "pending" | "done";

export interface Task {
  id: string;
  companyId: string;
  companyName: string;
  assignee: string;
  street: string;
  status: TaskStatus;
  createdAt: string;
  qualType?: QualificationType; // 缺省视为 "high_tech"，兼容现有数据
}

// ─── 复审状态 ────────────────────────────────────────────────────
export type RenewalStatus =
  | "overdue"     // 已过期未完成复审
  | "critical"    // ≤6个月到期（紧急）
  | "approaching" // 6-12个月（预警）
  | "active";     // >12个月，无需立即行动

// ─── 三年期经营指标（复审核心数据）──────────────────────────────
export interface ThreeYearMetrics {
  rdExpenseRatioY1: number;        // 研发费用占收入比(%)
  rdExpenseRatioY2: number;
  rdExpenseRatioY3: number;
  hiTechRevenueRatioY1: number;   // 高新产品收入占比(%)
  hiTechRevenueRatioY2: number;
  hiTechRevenueRatioY3: number;
  rdStaffRatioY1: number;          // 研发人员占比(%)
  rdStaffRatioY2: number;
  rdStaffRatioY3: number;
  newPatentsY1: number;            // 三年内新增专利数
  newPatentsY2: number;
  newPatentsY3: number;
  annualAuditPassedY1: boolean;
  annualAuditPassedY2: boolean;
  annualAuditPassedY3: boolean;
  complianceClean: boolean;        // 近3年无重大违规
}

// ─── 已认定高企（复审扩展类型）──────────────────────────────────
export interface CertifiedCompany extends Company {
  certifiedYear: number;           // 最近一次认定年份
  certNo: string;                  // 证书编号
  expiryYear: number;              // 到期年份 = certifiedYear + 3
  threeYearMetrics: ThreeYearMetrics;
  renewalStatus?: RenewalStatus;   // 运行时计算
}

// ─── 复审准备度评分结果 ──────────────────────────────────────────
export interface RenewalReadinessScore {
  total: number;
  rdRatioScore: number;            // 研发投入比(0-30分)
  hiTechRevenueScore: number;      // 高新收入比(0-30分)
  ipGrowthScore: number;           // 知识产权增长(0-20分)
  complianceScore: number;         // 合规与审计(0-20分)
  gaps: RenewalGap[];
  readyToRenew: boolean;           // total≥70 且无紧迫缺项
}

export interface RenewalGap {
  criterion: string;
  currentValue: string;
  requiredValue: string;
  urgent: boolean;
  suggestion: string;
}

// ─── 走访摸排（移动端）──────────────────────────────────────────

export interface Visitor {
  id: string;
  name: string;
  street: string | null;
  dept: string;
}

export type VisitMethod = "in_person" | "online";
export type WillingnessLevel = "strong" | "moderate" | "hesitant" | "refused" | "unreachable";

export interface VisitRecord {
  id: string;
  taskId: string;
  companyId: string;
  visitorId: string;
  visitorName: string;

  visitMethod: VisitMethod;
  visitedAt: string;
  visitDurationMinutes?: number;
  contactReached: boolean;
  actualContactName?: string;
  actualContactTitle?: string;
  actualContactPhone?: string;

  willingness: WillingnessLevel;
  willingnessNotes?: string;

  fieldVerified: {
    employeeCount?: number;
    rdEmployeeCount?: number;
    annualRevenue?: "under_500w" | "500w_2000w" | "2000w_1yi" | "above_1yi";
    rdExpenseRatio?: "under_3pct" | "3_5pct" | "5_10pct" | "above_10pct";
    rdExpenseSource?: "self_invested" | "government_grant" | "both" | "none";
    hasAccountingFirm?: boolean | null;
    hasTechDept?: boolean | null;
    mainProductDesc?: string;
  };

  // ─── 专精特新"小巨人"口径采集（仅 qualType==="little_giant" 的走访填充）────
  littleGiant?: {
    // 定位与经济效益
    industrialBaseCategory?: string;   // 工业六基第一层
    industrialBaseItem?: string;       // 第二层细分（或自定义）
    mainProductDesc?: string;          // 主导产品一句话（小巨人单一真值源，不写入 fieldVerified）
    annualRevenueBand?: "under_1yi" | "1_4yi" | "4_10yi" | "above_10yi";
    mainBizGrowth2y?: "neg" | "0_5pct" | "5_10pct" | "above_10pct";
    mainBizRevenueRatio?: "under_50" | "50_70" | "70_85" | "above_85"; // 门槛≥70%
    debtRatio?: "under_30" | "30_50" | "50_70" | "above_70";
    subdivisionYears?: "under_3" | "3_5" | "5_10" | "above_10";        // 门槛≥3年
    // 创新与产业链
    rdExpenseRatio?: "under_3pct" | "3_6pct" | "6_10pct" | "above_10pct"; // 门槛≥6%
    rdStaffRatio?: "under_10" | "10_20" | "20_30" | "above_30";
    hasProvincialRdInstitution?: boolean | null;
    standardsRole?: "international" | "national" | "industry" | "none";
    marketShare?: "national_top" | "provincial_top" | "regional_lead" | "unknown";
    fillsGapOrImportSub?: boolean | null;
    supplyChainRole?: string;
    hasOwnBrand?: boolean | null;
    bottleneckTraits?: string[];       // 卡脖子/补短板属性（多选）
    // 申报意愿与缺口
    expectedDeclareYear?: string;
  };

  acknowledgedGaps: string[];
  keyObstacles?: string;
  followUpDate?: string;
  companyCommitments?: string;
  nextSteps: string[];
  notes?: string;
  submittedAt: string;
}

// ─── 专业测评 ───────────────────────────────────────────────────

// 维度 id 由各资质测评配置（lib/assessment.ts）定义，故放宽为 string。
// 维度分自带 label / maxScore，渲染不依赖固定枚举。
export type AssessmentDimension = string;

export interface AssessmentOption {
  value: string;
  label: string;
  score: number;
}

export interface AssessmentQuestion {
  id: string;
  dimension: AssessmentDimension;
  text: string;
  hint?: string;
  options: AssessmentOption[];
  isQualifier: boolean;
}

export type AssessmentAnswers = Record<string, string>;

export interface AssessmentDimensionScore {
  dimension: AssessmentDimension;
  label: string;
  score: number;
  maxScore: number;
}

export interface CultivationSuggestion {
  dimension: AssessmentDimension;
  urgent: boolean;
  title: string;
  body: string;
}

export interface AssessmentScore {
  total: number;
  grade: "优秀" | "符合" | "待培育";
  dimensionScores: AssessmentDimensionScore[];
  suggestions: CultivationSuggestion[];
}

export type AssessmentSource = "enterprise_self" | "staff_agent";
export type AssessmentStatus = "pending" | "completed";

export interface AssessmentRecord {
  id: string;
  companyId: string;
  token: string;
  source: AssessmentSource;
  status: AssessmentStatus;
  createdAt: string;
  submittedAt?: string;
  submitterName?: string;
  answers?: AssessmentAnswers;
  score?: AssessmentScore;
  taskId?: string;
  qualType?: QualificationType; // 缺省视为 "high_tech"，兼容现有数据
}
